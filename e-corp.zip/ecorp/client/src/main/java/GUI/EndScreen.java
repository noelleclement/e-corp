package GUI;

/**
 * Created by Hans de Rooij on 14/03/2017.
 */
public class EndScreen extends ButtonlessScreen {
    public EndScreen() {
        super();
        this.mainTextLabel.setText("<html>Voltooid<br>Neem uw pas uit</html>");
    }
}
