package Backend;
import GUI.*;

/**
 * Created by Hans de Rooij on 09/05/2017.
 */
public class biljetkeuzeClass extends ScreenClass{
    public biljetkeuzeClass(GUI gui) {
        super(gui);
    }

    public void keyPressed(char key) {

    }
}
