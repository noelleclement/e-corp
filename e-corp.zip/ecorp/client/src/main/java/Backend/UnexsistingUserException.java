package Backend;

/**
 * Created by Hans de Rooij on 28/02/2017.
 */
public class UnexsistingUserException extends Exception {
    public UnexsistingUserException() {
        super();
    }
}
