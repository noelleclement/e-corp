/**
 * Created by Noelle on 31-03-17.
 */
package Printer;

public class AppPrinter {


    public static void main(String[] args){
        Printer printer = new Printer(1, "EVIL1234567", "2016-01-03", 50, 1, 1, 1);
        printer.print(false);
    }
}
