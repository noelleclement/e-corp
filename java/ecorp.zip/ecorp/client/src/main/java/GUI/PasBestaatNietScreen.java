package GUI;

/**
 * Created by Hans de Rooij on 10/04/2017.
 */
public class PasBestaatNietScreen extends ButtonlessScreen {
    public PasBestaatNietScreen() {
        super();
        this.mainTextLabel.setText("<html><p style=\"align: center;\"Deze pas wordt niet herkend<br>Neem hem uit</html>");
    }
}
