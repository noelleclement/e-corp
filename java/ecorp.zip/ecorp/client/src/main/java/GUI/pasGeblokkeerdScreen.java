package GUI;

/**
 * Created by Hans de Rooij on 07/04/2017.
 */
public class pasGeblokkeerdScreen extends ButtonlessScreen {
    public pasGeblokkeerdScreen() {
        super();
        this.mainTextLabel.setText("<html><p style='align:center;'>Deze pas is geblokkeerd<br>Neem contact op met uw bank</p></html>");
    }


}
