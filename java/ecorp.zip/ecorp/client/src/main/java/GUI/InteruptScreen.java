package GUI;

/**
 * Created by Hans de Rooij on 30/03/2017.
 */
public class InteruptScreen extends ButtonlessScreen {
    public InteruptScreen(){
        super();
        this.mainTextLabel.setText("<html>De transactie<br>is onderbroken<br>Verwijder uw pas</html>");
    }
}
